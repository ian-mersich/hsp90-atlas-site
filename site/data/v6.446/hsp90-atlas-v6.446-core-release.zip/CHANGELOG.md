# v6.446 — 2026-10-05

Reassesses all 4,148 existing source findings and 2,865 exact gene/HSP90-scope cases. One Candidate client relationship replaces competing Client and Candidate client labels. Strong, Moderate and Preliminary describe the evidence for substrate folding, maturation, maintenance, stability or competence in the reported context; they are project-defined grades, not probabilities or the historical comparison score.

Paper-level support and an authored combined assessment are separate. Combined assessments do not cross gene or reported HSP90 scope, and are not calculated as the largest paper grade. Table filters, profile summaries, network interpretation and JSON/TSV/GraphML downloads use the same decisions. Binding alone remains Physical association; mature-protein regulation, RNA, correlation and pathway effects alone do not nominate a client. Explicit scope conflicts are withheld from current interpretation pending source checking.

GraphML uses explicit UTF-8 input and canonical LF output, preserving scientific text and making the standalone export byte-identical to its copy in the release bundle after publication.

This is a reassessment of existing reviewed source records with targeted backtracing, not a fresh full-paper reading of all 4,148 findings or completion of the discovery-lead queue. The v6.445 NR1H3 finding and FASN/MAP1B descriptive corrections are retained, not newly added in this release. Original source assertions, pair membership, source scope, historical scores and the frozen analysis benchmark are preserved. The Cycle retains its v6.443 evidence and v6.303 model, with only the current Atlas label changed. Affected HPA/CPTAC summaries and private bulk observations remain withheld. Manuscript work remains on hold.
